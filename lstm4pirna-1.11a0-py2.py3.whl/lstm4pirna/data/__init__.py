import os

lstm4pirna_path= os.path.join(os.path.dirname(__file__))

