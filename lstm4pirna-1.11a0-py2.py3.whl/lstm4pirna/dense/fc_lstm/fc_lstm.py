import torch
import torch.nn as nn
import torch.nn.functional as F

class conv_block(nn.Module):
    def __init__(self,ch_in,ch_out):
        super(conv_block,self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=3,stride=1,padding=1,bias=True),
            nn.BatchNorm2d(ch_out),
            nn.ReLU(inplace=True),
            nn.Conv2d(ch_out, ch_out, kernel_size=3,stride=1,padding=1,bias=True),
            nn.BatchNorm2d(ch_out),
            nn.ReLU(inplace=True))

    def forward(self,x):
        x = self.conv(x)
        return x


class up_conv(nn.Module):
    def __init__(self,ch_in,ch_out):
        super(up_conv,self).__init__()
        self.up = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(ch_in,ch_out,kernel_size=3,stride=1,padding=1,bias=True),
            nn.BatchNorm2d(ch_out),
            nn.ReLU(inplace=True))

    def forward(self,x):
        x = self.up(x)
        return x


class LSTM(nn.Module):
    def __init__(self,dropout: float = 0.0, img_ch: int=3, output_ch: int=1):
        super(LSTM,self).__init__()
        self.size_h= 32
        self.drop= dropout
        print(f'drop={self.drop}')
        self.lstm= torch.nn.LSTM(
                #x(B_n,seq=28,feature=28)
                input_size= 4,
                hidden_size= self.size_h,
                num_layers= 3,
                # Reorder (batch,seq,feature)
                dropout= self.drop,
#                dropout=0.0,
                bidirectional= False,
                batch_first= True
                )
        
        self.norm= torch.nn.BatchNorm1d(self.size_h)
        self.norm2= torch.nn.BatchNorm1d(2)
        self.drop= torch.nn.Dropout(self.drop)
        self.class2= torch.nn.Sequential(
                  # x(B_n,512,4,4)
                  #torch.nn.Linear(48*48,512),
                  # x(B_n,1024)
                  #torch.nn.ReLU(),
                  torch.nn.Linear(self.size_h,2))



    def forward(self,x,L1):
        # encoding path
        [d1,h1]= self.lstm(x)
        # state output
        d2=d1[[*range(len(L1))],L1-1,:]
        d2= self.norm(d2)
        d2= self.drop(d2)

        t3= self.class2(d2)
        t3= t3.squeeze(1)
        t4= torch.softmax(t3, dim=1)

        return t4


