# LSTM4piRNA
The users are welcome to use LSTM4piRNA webserver available at https://lstm4pirna.ee.ncyu.edu.tw for RNA structure prediction. REDfold is implemented in Python code and cross-platform compatible.

#System Requirement
	python (>=3.7)
	biopython (>=1.79)
	numpy (>=1.21)
	pandas(>=1.3.5)
	scipy (>=1.7.3)
	torch (>=1.9+cu111)


#Install
  %pip install lstm4pirna-1.14a0-py2.py3-none-any.whl


#Predict RNA Structure
LSTM4piRNA test for predicting RNA secondary structure with fasta-formatted RNA sequences.

  %lstm4pirna directory_containing_fasta_files


#Train parameters
LSTM4piRNA can train the parameters with fasta-formatted RNA sequences.

  %lstm4pirna -train directory_positive_files directory_negative_files

#Configure parameters
Configure parameters in json format.
  BATCH_SIZE: test batch size
	batch_size_stage_1: dataload batch size
  out_step: output batch size
	load_model: read training model
  test_data: test data file
	data_type: test data directory
  model_type: test model file
	epoches_first: training iteration
	set_gamma: optimization hyperparm shuffle
	set_beta: optimization hyperparm dropout
	set_L1: optimization constraint L1


# Web Server
LSTM4piRNA web server is available at https://lstm4pirna.ee.ncyu.edu.tw

#References
Chun-Chi Chen, Yi-Ming Chan, "LSTM4piRNA: Accurate RNA Secondary Structure Prediction using Residual Encoder-Decoder Network"

